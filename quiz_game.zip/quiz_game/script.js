const startButton = document.getElementById('start-btn');
const nextButton = document.getElementById('next-btn');
const questionContainerElement = document.getElementById('question-container');
const questionElement = document.getElementById('question');
const answerButtonElement = document.getElementById('answer-buttons');
let message = document.getElementById('message');
let time = document.getElementById('time');
let shuffledQuestions, currentQuestionIndex;

startButton.addEventListener('click', startGame);
nextButton.addEventListener('click', () => {
  currentQuestionIndex++;
  setNextQuestion();
});

function startGame() {
  c = 50;

  console.log('started');

  startButton.classList.add('hide');
  message.innerHTML = '';

  shuffledQuestions = questions.sort(() => Math.random() - 0.5);
  currentQuestionIndex = 0;
  questionContainerElement.classList.remove('hide'); //showing question
  setNextQuestion();
}

function setNextQuestion() {
  resetState();
  showQuestion(shuffledQuestions[currentQuestionIndex]);
}

function showQuestion(question) {
  questionElement.innerText = question.question;
  question.answers.forEach((answer) => {
    const button = document.createElement('button');
    button.innerText = answer.text;
    button.classList.add('btn');
    if (answer.correct) {
      button.dataset.correct = answer.correct;
    }
    button.addEventListener('click', selectAnswer);
    answerButtonElement.appendChild(button);
  });
}

function resetState() {
  //error not reseting and not removing extra answers
  clearStatusClass(document.body);
  nextButton.classList.add('hide');
  while (answerButtonElement.firstChild) {
    answerButtonElement.removeChild(answerButtonElement.firstChild);
  }
}

function selectAnswer(e) {
  // s = 0;
  // s++;
  // score.innerHTML =  s;
  const selectedButton = e.target;
  const correct = selectedButton.dataset.correct;
  setStatusClass(document.body, correct);
  Array.from(answerButtonElement.children).forEach((button) => {
    setStatusClass(button, button.dataset.correct);
  });
  if (shuffledQuestions.length > currentQuestionIndex + 1) {
    nextButton.classList.remove('hide');
  }
  //else if (s = 5) {
  //     message.innerHTML=" End of Quiz" + "</br>"+ "Excellent..! ";
  //     startButton.innerText = 'restart'
  //     startButton.classList.remove('hide')
  // }else if (s = 4) {
  //     message.innerHTML=" End of Quiz"+ "</br>"+ "Very Good..! ";
  //     startButton.innerText = 'restart'
  //     startButton.classList.remove('hide')
  // }else if (s = 3) {
  //     message.innerHTML=" End of Quiz"+ "</br>"+ "Good..! ";
  //     startButton.innerText = 'restart'
  //     startButton.classList.remove('hide')
  // }else if (s = 2) {
  //     message.innerHTML=" End of Quiz"+ "</br>"+ "Fair..! ";
  //     startButton.innerText = 'restart'
  //     startButton.classList.remove('hide')
  // }else if (s = 1) {
  //     message.innerHTML=" End of Quiz"+ "</br>"+ "Batter Luck Next Time ..! ";
  //     startButton.innerText = 'restart'
  //     startButton.classList.remove('hide')
  // }
  else {
    window.clearInterval(update);
    c = '-';
    message.innerHTML = 'End of Quiz'; //reset remove
    startButton.innerText = 'restart';
    startButton.classList.remove('hide');
  }
}

function setStatusClass(element, correct) {
  clearStatusClass(element);
  if (correct) {
    element.classList.add('correct');
  } else {
    element.classList.add('wrong');
  }
}

function clearStatusClass(element) {
  element.classList.remove('correct');
  element.classList.remove('wrong');
}

function timer() {
  c = c - 1; // c is the counter here
  if (c < 50) {
    time.innerHTML = c;
  }
  if (c < 1) {
    window.clearInterval(update);
    message.innerHTML = ' Times Up'; //reset remove
    startButton.innerText = 'restart';
    startButton.classList.remove('hide');
  }
}
update = setInterval('timer()', 1000);

// function scores(){
//     score.innerHTML = s++;
//  }
const questions = JSON.parse(localStorage.getItem('Quiz'));

//  -----------------------------------------------------

// let quiz = JSON.parse(localStorage.getItem('Quiz'));
// console.log(quiz);
// var QuizView = document.getElementById('AllQuestions');
// var view = quiz.map((v, i) => {
//   return `<div><div class='alert alert-success'>
//                 <h3 class="text-capitalize">${v.Question}</h3>
//                 <h3 class="text-capitalize">${v.A}</h3>
//                 <h3 class="text-capitalize">${v.B}</h3>
//                 <h3 class="text-capitalize">${v.C}</h3>
                // <h3 class="text-capitalize">${v.D}</h3>
//                 <h3 class="text-capitalize">${v.Correct}</h3>
//                 </div></div>`;
// });

// QuizView.innerHTML = view.join('');
