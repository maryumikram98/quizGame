document.getElementById('myform').addEventListener('submit', () => QuizGame());

const QuizGame = () => {
  let question = document.getElementById('question').value;
  let option_A = document.getElementById('optionA').value;
  let option_B = document.getElementById('optionB').value;
  let option_C = document.getElementById('optionC').value;
  // let option_D = document.getElementById('optionD').value;
  let correctOption = document.getElementById('correctOption').value;

  let Quiz = {
    question: question,
    answers: [
      { text: option_A, correct: correctOption == 'A' ? true : false },
      { text: option_B, correct: correctOption == 'B' ? true : false },
      { text: option_C, correct: correctOption == 'C' ? true : false },
      // { text: option_D, correct: correctOption == 'D' ? true : false },
    ],
  };

  if (localStorage.getItem('Quiz') === null) {
    var quiz = [];
    quiz.push(Quiz);
    localStorage.setItem('Quiz', JSON.stringify(quiz));
  } else {
    quiz = JSON.parse(localStorage.getItem('Quiz'));
    quiz.push(Quiz);
    localStorage.setItem('Quiz', JSON.stringify(quiz));
  }

  document.getElementById('question').value = '';
  document.getElementById('optionA').value = '';
  document.getElementById('optionB').value = '';
  document.getElementById('optionC').value = '';
  // document.getElementById('optionD').value = '';
  document.getElementById('correctOption').value = '';
};
